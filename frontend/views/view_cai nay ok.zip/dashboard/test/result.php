<?php
/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\helpers\Url;

$this->title = 'Result';
?>
<h1>YOUR RESULT</h1>
<h3>TRUE <?= $mark[0] ?>/<?= $mark[1] ?></h3>
